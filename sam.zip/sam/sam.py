from flask import Flask, jsonify
from flask_cors import CORS


app = Flask(__name__)
CORS(app)

@app.route("/des1")
def horario1():
    return "Se cree que Sam nació a principios de la década de 1940. Su historia comienza en 1941, durante la Segunda Guerra Mundial."
@app.route("/des2")
def horario2():
    return "Después de estos incidentes, Sam fue finalmente retirado de la marina y enviado a tierra en 1943. Se retiró con la tripulación del HMS Ark Royal, que ya estaba fuera de servicio tras su ataque."

@app.route("/des3")
def horario3():
    return "Los gatos en los barcos se usaban principalmente para controlar la población de roedores y plagas, protegiendo los suministros y cables. Además, brindaban compañía a los marineros, ayudando a aliviar la soledad y el estrés."

@app.route('/imagen')
def imagen():
    return jsonify({'src': 'https://historia.nationalgeographic.com.es/medio/2023/07/10/insumergible-sam-georgina-shaw-baker-greenwich-maritime-national-museum_d070f75e_230710193559_800x1139.jpg'})

@app.route("/sam")
def hello():
    return "Sam el insumergible,es un gato que, supuestamente, sobrevivió al hundimiento de no solo una sino tres naves durante la guerra: el acorazado alemán Bismarck, el destructor británico Cossack y el portaaviones británico Ark Royal. Esto lo convertiría en una de las mascotas con más suerte de aquel conflicto, aunque la verdad es que no hay pruebas de que se tratase del mismo gato."

if __name__ == "__main__":
    app.run(debug=True)
