
$(document).ready(function () {

    $("#btnvideo").click(function () {
        $("#video1").slideToggle();
    });


$("#btntexto").click(function () {
    if ($("#texto0").is(":hidden")) {
        $.get("http://127.0.0.1:5000/sam", function (data, status) {
            $("#texto0").html(data);
            $("#texto0").fadeIn(2000);
        });
    } else {
        $("#texto0").fadeOut(2000);
    }
});

$("#imagen1").click(function () {
    if ($("#texto11").is(":hidden")) {
        $.get("http://127.0.0.1:5000/des1", function (data, status) {
            $("#texto11").html(data);
            $("#texto11").fadeIn();
        });
    } else {
        $("#texto11").fadeOut();
    }
});


$("#imagen2").click(function () {
    if ($("#texto22").is(":hidden")) {
        $.get("http://127.0.0.1:5000/des2", function (data, status) {
            $("#texto22").html(data);
            $("#texto22").fadeIn();
        });
    } else {
        $("#texto22").fadeOut();
    }
});


$("#imagen3").click(function () {
    if ($("#texto33").is(":hidden")) {
        $.get("http://127.0.0.1:5000/des3", function (data, status) {
            $("#texto33").html(data);
            $("#texto33").fadeIn();
        });
    } else {
        $("#texto33").fadeOut();
    }
});

$("#imagen0").mouseover(function () {
    $.get("http://127.0.0.1:5000/imagen", function (data, status) {
        $("#imagen0").fadeOut(1000, function () {
            $(this).attr("src", data.src);
            $(this).fadeIn(300);
        });
    });
});



});